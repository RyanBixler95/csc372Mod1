package csc372mod1;

import java.util.Scanner;

public class Test {
	public static void main(String[] args)	{
		Scanner scnr = new Scanner(System.in);
		
		System.out.println("========| Welcome to Bank of Ryan |========\n");
		System.out.println("To access your account please input your Account Number:");
		int accountID = scnr.nextInt();
		scnr.nextLine();
		
		System.out.println("For security purposes, please input your first name followed by your last name:");
		String firstName = scnr.next();
		String lastName = scnr.next();
		
		CheckingAccount account = new CheckingAccount(1.5);
		account.setFirstName(firstName);
		account.setLastName(lastName);
		account.setAccountID(accountID);
		
		System.out.println("\nThank You!\n");
		System.out.println("Please input your preferred cash deposit amount:");
		double deposit = scnr.nextDouble();
		account.deposit(deposit);
		
		System.out.println("If you would like to make a withdrawal, please input the amount, if none input N/A:");
		String withdrawalInput = scnr.next();
		if(!withdrawalInput.equalsIgnoreCase("N/A"))	{
			double withdrawal = Double.parseDouble(withdrawalInput);
			account.processWithdrawal(withdrawal);
		}
		
		account.applyInterest();
		
		account.displayAccountSummary(deposit, withdrawalInput);
		
		scnr.close();
	}

}
