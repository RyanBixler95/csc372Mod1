package csc372mod1;

public class BankAccount {
		private String firstName;
		private String lastName;
		private int accountID;
		private double balance;
		
		public BankAccount()	{
			this.balance = 0.0;
		}
		
		public void deposit(double amount)	{
			if(amount > 0)	{
				balance += amount;
			}
		}
		
		public void withdraw(double amount)	{
			if(amount > 0 && amount <= balance)	{
				balance -= amount;
			} else if(amount > balance)	{
				System.out.println("Insufficient funds for withdrawal.");
			}
		}
		
		public String getFirstName()	{
			return firstName;
		}
		
		public void setFirstName(String firstName)	{
			this.firstName = firstName;
		}
		
		public String getLastName()	{
			return lastName;
		}
		
		public void setLastName(String lastName)	{
			this.lastName = lastName;
		}
		
		public int getAccountID()	{
			return accountID;
		}
		
		public void setAccountID(int accountID)	{
			this.accountID = accountID;
		}
		
		public double getBalance()	{
			return balance;
		}
		
		public void setBalance(double balance)	{
			this.balance = balance;
		}

		public void accountSummary()	{
			System.out.printf("\nAccount Summary:\n");
			System.out.printf("First Name:  %s\n", firstName);
			System.out.printf("Last Name:  %s\n", lastName);
			System.out.printf("Account ID:  %d\n", accountID);
			System.out.printf("Balance:  $%.2f\n", balance);
		}
	
}
