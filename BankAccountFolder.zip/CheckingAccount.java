package csc372mod1;

public class CheckingAccount extends BankAccount{
		private double interestRate;
		private boolean overdraftOccurred = false;
		
		public CheckingAccount(double interestRate)	{
			super();
			this.interestRate = interestRate;
		}
		
		public void processWithdrawal(double amount)	{
			double fee = 30.0;
			double currentBalance = getBalance();
			if(amount > 0 && amount <= currentBalance)	{
				withdraw(amount);
			} else if(amount > currentBalance)	{
				double overdraftAmount = amount - currentBalance;
				setBalance(-overdraftAmount - fee);
				overdraftOccurred = true;
			}
		}
		
		public void applyInterest()	{
			double currentBalance = getBalance();
			double interest = currentBalance * (interestRate / 100);
				setBalance(currentBalance + interest);
			
		}
		
		public double getInterestRate()	{
			return interestRate;
		}
		
		public boolean isOverdraftOccurred()	{
			return overdraftOccurred;
		}
		
		public void displayAccountSummary(double deposit, String withdrawalInput)	{
			System.out.println("\nAccount Summary:");
			System.out.printf("FIRST NAME:  %s\n", getFirstName());
			System.out.printf("LAST NAME:  %s\n", getLastName());
			System.out.printf("ACCOUNT ID:  %d\n", getAccountID());
			System.out.printf("INTEREST RATE:  %.1f%%\n", getInterestRate());
			System.out.printf("BALANCE:  $%.2f\n", getBalance());
			System.out.println("\nHISTORY OF RECENT BANK TRANSACTIONS:");
			System.out.printf("$%.2f Deposited\n", deposit);
			if(!withdrawalInput.equalsIgnoreCase("N/A"))	{
				double withdrawal = Double.parseDouble(withdrawalInput);
				System.out.printf("$%.2f Withdrawn\n", withdrawal);
				if(isOverdraftOccurred())	{
					System.out.println("$30.00 Overdraft Fee Charged to Account");
				}
			}
		}

	}
